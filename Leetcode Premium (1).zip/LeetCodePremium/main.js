$(document).ready(function() {
    console.log("Welcome to LeetFree.com!");
} );
